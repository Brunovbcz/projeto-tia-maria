//Consts
const username = '';
const password = '';

const loginButton = document.querySelector('.login-button');
const errorMessage = document.querySelector('.error-message');
const menuButton = document.querySelector('#menu-img');

//Pages
const loginPage = document.querySelector('.login-page');
const initialPage = document.querySelector('.initial-page');

function changePages(hiddenPage, actualPage, displayType){
    hiddenPage.style.display = 'none';
    actualPage.style.display = displayType;
}

loginButton.addEventListener('click', () => {
    let userIn = document.querySelector('#user');
    let passIn = document.querySelector('#senha');

    if (passIn.value === password && userIn.value === username){
        if (errorMessage.classList.contains('visible')) errorMessage.classList.remove('visible');
        changePages(loginPage, initialPage, 'flex');
        let text = document.querySelector('header').querySelector('a')
        text.textContent = 'Olá ' + username
    }else{
        if (passIn.value === '' || userIn.value === '') return
        errorMessage.classList.add('visible')
    }
})

menuButton.addEventListener('click', () => {
    let container = document.querySelector('.side-container');
    let menuImg = document.querySelector('#menu-img')
    let vendasPage = document.querySelector('.vendas-page')
    container.classList.toggle('visible');
    menuImg.classList.toggle('visible')
    vendasPage.classList.toggle('reduced')
})