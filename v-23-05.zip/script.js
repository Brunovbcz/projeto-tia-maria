//Consts
const username = '';
const password = '';

const loginButton = document.querySelector('.login-button');
const errorMessage = document.querySelector('.error-message');

//Pages
const loginPage = document.querySelector('.login-page');
const initialPage = document.querySelector('.initial-page');

function changePages(hiddenPage, actualPage, displayType){
    hiddenPage.style.display = 'none';
    actualPage.style.display = displayType;
}

loginButton.addEventListener('click', () => {
    let userIn = document.querySelector('#user');
    let passIn = document.querySelector('#senha');

    if (passIn.value === password && userIn.value === username){
        if (errorMessage.classList.contains('visible')) errorMessage.classList.remove('visible');
        changePages(loginPage, initialPage, 'flex');
        let profileButton = document.querySelector('.profile-button').querySelector('a')
        profileButton.textContent = 'Olá ' + username
    }else{
        if (passIn.value === '' || userIn.value === '') return
        errorMessage.classList.add('visible')
    }
})