//Consts
const username = 'a';
const password = 'a';

let loginButton = document.querySelector('.login-button');

const errorMessage = document.querySelector('.error-message')

loginButton.addEventListener('click', () => {
    let userIn = document.querySelector('#user');
    let passIn = document.querySelector('#senha');

    if (passIn.value === password && userIn.value === username){
        console.log(passIn, userIn)
    }else{
        errorMessage.style.display = 'flex';
        errorMessage.classList.toggle('visible')
    }
})